/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IRPhase1;

import java.io.*;
import java.util.*;

/**
 *
 * @author Dinesh
 */
public class Tokenizer {

    /*The object called 'Tokenizer' splits the 1400 documents text into tokens and forms 1400 tokens files.
     The 'Tokenizer' object has two parameters.First parameter is string and Second parameter is an Tokenization indicator.
     It will be 'F' if document text is being parsed into tokens
     Otherwise 'Q' if user Query is being parsed into tokens
    Inaddition to this, the stop-words also will be removed from the tokenized text*/
    
    public String[] Stopwordscheck(String chk) {
        
   /*All the Stopwords are written into multiple arrays based on their alphabetical letters.
     Each token is being checked with the array of stop-words elements and writing the same 
     token on the disk will be bypassed if it matches.*/
        
        String[] a1 = {"Hai"};
        String[] a = {"a", "a's", "able", "about", "above", "according", "accordingly", "across", "actually", "after", "afterwards", "again", "against", "ain't", "all", "allow", "allows", "almost", "alone", "along", "already", "also", "although",
            "always", "am", "among", "amongst", "an", "and", "another", "any", "anybody", "anyhow", "anyone", "anything", "anyway", "anyways", "anywhere", "apart",
            "appear", "appreciate", "appropriate", "are", "aren't", "around", "as", "aside", "ask", "asking", "associated", "at", "available", "away", "awfully"};

        String[] b = {"b", "be", "became", "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being",
            "believe", "below", "beside", "besides", "best", "better", "between", "beyond", "both", "brief", "but", "by"};

        String[] c = {"c", "c'mon", "c's", "came", "can", "can't", "cannot", "cant", "cause", "causes", "certain", "certainly", "changes", "clearly", "co", "com", "come", "comes", "concerning", "consequently", "consider", "considering",
            "contain", "containing", "contains", "corresponding", "could", "couldn't", "course", "currently"};

        String[] d = {"d", "definitely", "described", "despite", "did", "didn't", "different", "do", "does", "doesn't", "doing",
            "don't", "done", "down", "downwards", "during"};
        String[] e = {"e", "each", "edu", "eg", "eight", "either", "else", "elsewhere", "enough", "entirely", "especially", "et", "etc",
            "even", "ever", "every", "everybody", "everyone", "everything", "everywhere", "ex", "exactly", "example", "except"};
        String[] f = {"f", "far", "few", "fifth", "first", "five", "followed", "following", "follows", "for", "former", "formerly", "forth",
            "four", "from", "further", "furthermore"};
        String[] g = {"g", "get", "gets", "getting", "given", "gives", "go", "goes", "going", "gone", "got", "gotten", "greetings"};
        String[] h = {"h", "had", "hadn't", "happens", "hardly", "has", "hasn't", "have", "haven't", "having", "he", "he's", "hello", "help",
            "hence", "her", "here", "here's", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "hi", "him", "himself", "his", "hither", "hopefully", "how", "howbeit", "however"};
        String[] i = {"i", "i'd", "i'll", "i'm", "i've", "ie", "if", "ignored", "immediate", "in", "inasmuch", "inc", "indeed", "indicate",
            "indicated", "indicates", "inner", "insofar", "instead", "into", "inward", "is", "isn't", "it", "it'd", "it'll", "it's", "its", "itself"};
        String[] j = {"j", "just"};
        String[] k = {"k", "keep", "keeps", "kept", "know", "knows", "known"};
        String[] l = {"l", "last", "lately", "later", "latter", "latterly", "least", "less", "lest", "let", "let's", "like", "liked", "likely",
            "little", "look", "looking", "looks", "ltd"};
        String[] m = {"m", "mainly", "many", "may", "maybe", "me", "mean", "meanwhile", "merely", "might", "more", "moreover", "most", "mostly",
            "much", "must", "my", "myself"};
        String[] n = {"n", "name", "namely", "nd", "near", "nearly", "necessary", "need", "needs", "neither", "never", "nevertheless", "new",
            "next", "nine", "no", "nobody", "non", "none", "noone", "nor", "normally", "not", "nothing", "novel", "now", "nowhere"};
        String[] o = {"o", "obviously", "of", "off", "often", "oh", "ok", "okay", "old", "on", "once", "one", "ones", "only", "onto", "or", "other",
            "others", "otherwise", "ought", "our", "ours", "ourselves", "out", "outside", "over", "overall", "own"};
        String[] p = {"p", "particular", "particularly", "per", "perhaps", "placed", "please", "plus", "possible", "presumably", "probably", "provides"};
        String[] q = {"q", "que", "quite", "qv"};
        String[] r = {"r", "rather", "rd", "re", "really", "reasonably", "regarding", "regardless", "regards", "relatively", "respectively",
            "right"};
        String[] s = {"s", "said", "same", "saw", "say", "saying", "says", "second", "secondly", "see", "seeing", "seem", "seemed", "seeming",
            "seems", "seen", "self", "selves", "sensible", "sent", "serious", "seriously", "seven", "several", "shall", "she", "should", "shouldn't", "since", "six",
            "so", "some", "somebody", "somehow", "someone", "something", "sometime", "sometimes", "somewhat", "somewhere", "soon", "sorry", "specified",
            "specify", "specifying", "still", "sub", "such", "sup", "sure"};

        String[] t = {"t", "t's", "take", "taken", "tell", "tends", "th", "than", "thank", "thanks", "thanx", "that", "that's", "thats", "the",
            "their", "theirs", "them", "themselves", "then", "thence", "there", "there's", "thereafter", "thereby", "therefore", "therein",
            "theres", "thereupon", "these", "they", "they'd", "they'll", "they're", "they've", "think", "third", "this", "thorough", "thoroughly",
            "those", "though", "three", "through", "throughout", "thru", "thus", "to", "together", "too", "took", "toward", "towards", "tried", "tries", "truly", "try", "trying", "twice", "two"};
        String[] u = {"u", "un", "under", "unfortunately", "unless", "unlikely", "until", "unto", "up", "upon", "us", "use", "used", "useful",
            "uses", "using", "usually", "uucp"};
        String[] v = {"v", "value", "various", "very", "via", "viz", "vs"};
        String[] w = {"w", "want", "wants", "was", "wasn't", "way", "we", "we'd", "we'll", "we're", "we've", "welcome", "well", "went", "were", "weren't",
            "what", "what's", "whatever", "when", "whence", "whenever", "where", "where's", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", "who's", "whoever", "whole", "whom", "whose", "why", "will",
            "willing", "wish", "with", "within", "without", "won't", "wonder", "would", "would", "wouldn't"};
        String[] x = {"x"};
        String[] y = {"y", "yes", "yet", "you", "you'd", "you'll", "you're", "you've", "your", "yours", "yourself", "yourselves"};
        String[] z = {"z", "zero"};

        if ("a".equals(chk)) {
            a1 = a;
        }
        if ("b".equals(chk)) {
            a1 = b;
        }
        if ("c".equals(chk)) {
            a1 = c;
        }
        if ("d".equals(chk)) {
            a1 = d;
        }
        if ("e".equals(chk)) {
            a1 = e;
        }
        if ("f".equals(chk)) {
            a1 = f;
        }
        if ("g".equals(chk)) {
            a1 = g;
        }
        if ("h".equals(chk)) {
            a1 = h;
        }
        if ("i".equals(chk)) {
            a1 = i;
        }
        if ("j".equals(chk)) {
            a1 = j;
        }
        if ("k".equals(chk)) {
            a1 = k;
        }
        if ("l".equals(chk)) {
            a1 = l;
        }
        if ("m".equals(chk)) {
            a1 = m;
        }
        if ("n".equals(chk)) {
            a1 = n;
        }
        if ("o".equals(chk)) {
            a1 = o;
        }
        if ("p".equals(chk)) {
            a1 = p;
        }
        if ("q".equals(chk)) {
            a1 = q;
        }
        if ("r".equals(chk)) {
            a1 = r;
        }
        if ("s".equals(chk)) {
            a1 = s;
        }
        if ("t".equals(chk)) {
            a1 = t;
        }
        if ("u".equals(chk)) {
            a1 = u;
        }
        if ("v".equals(chk)) {
            a1 = v;
        }
        if ("w".equals(chk)) {
            a1 = w;
        }
        if ("x".equals(chk)) {
            a1 = x;
        }
        if ("y".equals(chk)) {
            a1 = y;
        }
        if ("z".equals(chk)) {
            a1 = z;
        }
        return a1;
    }

    /*writeintofiles function contains 4 parameters.
      Input_String is supposed to be parsed into multiple tokens.
      ind will be 'Q' if query is being parsed into tokens
                  'F' if files are being parsed into tokens
      when ind is 'F'
            -outfile is the individual text file , in which respective document tokens are to be written
            -alloutfile is the text file,in which all the documents tokens are to be written. 
      when ind is 'Q'
            -outfile is the Query tokens text file , in which query tokens are to be written.
            -alloutfile is not being used for the query parsing procedure.
    */
    public void writeintofiles(String Input_String, PrintStream outfile, PrintStream alloutfile, char ind) {
    // Tokenize the given input string based on multiple special characters like . - / ( ) : 
        StringTokenizer Tokenized_String = new StringTokenizer(Input_String, " ||.||-||,||/||(||)||:");
        stemmer Stemmer = new stemmer();

        while (Tokenized_String.hasMoreTokens()) {
            String Current_Token = Tokenized_String.nextToken();
            Current_Token = Current_Token.toLowerCase();
            String chk = Current_Token.substring(0, 1);

            String[] a1 = Stopwordscheck(chk);
            int inter = 0;
            for (int outt = 0; outt < a1.length && inter == 0; outt++) {
                if (a1[outt].equals(Current_Token)) {
                    inter = inter + 1;
                }
            }
            for (int mn = 0; mn < Current_Token.length() && inter == 0; mn++) {
                if (!Character.isLetter(Current_Token.charAt(mn))) {
                    inter = inter + 1;
                }
            }

            if (inter == 0) {
                for (int index = 0; index < Current_Token.length(); index++) {
                    char aChar = Current_Token.charAt(index);
                    Stemmer.add(aChar);
                }
        //Porter Stemmer is being called to stem the tokens        
                Stemmer.stem();
                Current_Token = Stemmer.toString();
                outfile.println(Current_Token);

                if ('F' == ind) {
                    alloutfile.println(Current_Token);
                }

            }

        }

    }

    public String Tokenizer(String Input_String, char Stopwords_Ind) {
        try {
      
   //The 1400 documents tokens will be written into the alltokenz.txt file.
            
            String alltokenout1 = "C:/Users/Dinesh/Desktop/IR_ASG1/Token/alltokenz.txt";
            PrintStream outfile1 = new PrintStream(new FileOutputStream(alltokenout1));
            
   //Tokenize the User given Query and write the same on to the disk file "QueryTokens.txt" 
            
            if ('Q' == Stopwords_Ind) {
                String QueryTokens_File = "C:/Users/Dinesh/Desktop/IR_ASG1/QueryTokens.txt";
                PrintStream Query_File = new PrintStream(new FileOutputStream(QueryTokens_File));
                writeintofiles(Input_String, Query_File, outfile1, 'Q');
  //Tokenize all the documents text and write the same on to their respective disk files "*.txt"
            } else {
                for (int ddd = 1; ddd <= 1400; ddd++) {
                    String tokeninfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Docs/" + ddd + ".txt";
                    String tokenoutfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Token/" + ddd + ".txt";

                    FileReader infileReader = new FileReader(tokeninfile);
                    BufferedReader infile = new BufferedReader(infileReader);
                    PrintStream outfile = new PrintStream(new FileOutputStream(tokenoutfile));

                    while ((Input_String = infile.readLine()) != null) {
                        writeintofiles(Input_String, outfile, outfile1, 'F');

                    }
                }
            }

            if ('F' == Stopwords_Ind) 
            {
                System.out.println("All the given documents are tokenized");
            }
            else
            {
                System.out.println("User given query is tokenized");
            }
        } 
        catch (IOException ex) {
            System.out.println(ex);
        }
        return "DoneSuccessfully";

    }  

}
