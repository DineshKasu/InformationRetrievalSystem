/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IRPhase1;

import java.io.*;
import java.util.*;

/**
 *
 * @author Dinesh
 */
public class Parser {

    /**
     * @param args the command line arguments
     */
    public static String tokenfreq(String s, int m) {
        int zz = 0;
        try {
            String documnt = "C:/Users/Dinesh/Desktop/IR_ASG1/Token/" + m + ".txt";
            BufferedReader innn = new BufferedReader(new FileReader(documnt));
            String dk;
            while ((dk = innn.readLine()) != null) {
                if ((dk.equals(s))) {

                    zz = zz + 1;
                }
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }

        String docm = Integer.toString(zz);
        return docm;
    }

    public static void main(String[] args) {
        
        //The input is cran feild collection and it will be parsed into 1400 multiple documents based on the abstracts
        
        String cranfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Main/cran.all";
        try {
            FileReader CranFileReader = new FileReader(cranfile);
            BufferedReader CranFileBufferedReader = new BufferedReader(CranFileReader);
            PrintStream writeindoc = null;
            int docnumber = 1;
            String CranFileText;
               
        // Cran Field collection is being divided into multiple documents 
            
            while ((CranFileText = CranFileBufferedReader.readLine()) != null) {
                if (!".I".equals(CranFileText.substring(0, 2))) {
                    writeindoc.println(CranFileText);
                } else {
                    if (!"1".equals(CranFileText.substring(3))) {
                        writeindoc.close();
                    }
                    String outdoc = "C:/Users/Dinesh/Desktop/IR_ASG1/Docs/" + docnumber + ".txt";
                    writeindoc = new PrintStream(new FileOutputStream(outdoc));
                    docnumber++;
                }
            }

            int Totalnofdocs = docnumber - 1;
            System.out.println("No of documents created are " + Totalnofdocs);
            
      /*Call The object 'Tokenizer',which splits the 1400 documents text into tokens and forms 1400 tokens files.
       The 'Tokenizer' object has two parameters.First parameter is string and Second parameter is an Tokenization 
       indicator.It will be 'F' if document text is being parsed into tokens 
       Otherwise 'Q' if user Query is being parsed into tokens.
       Inaddition to this, the stop-words also will be removed from the tokenized text*/      
            
            Tokenizer T = new Tokenizer();
            T.Tokenizer("Tokenize the documents text", 'F');
            
     /*Treeset keeps the tokens in a tree structue,which will be automatically sorted into the ascending order 
            and also removes the duplicate tokens from the tree structure*/
            TreeSet<String> treeset = new TreeSet<>();

     // Add all the documents tokens into treeset to get the sorting order
            for (int docs = 1; docs <= 1400; docs++) {
                String documnt = "C:/Users/Dinesh/Desktop/IR_ASG1/Token/" + docs + ".txt";
                BufferedReader tokendoc = new BufferedReader(new FileReader(documnt));
                String Readstring;

                while ((Readstring = tokendoc.readLine()) != null) {
                    treeset.add(Readstring);
                }
            }

            System.out.println("All the stemmed tokens are copied into treeset");

             /* Loop the treeset and take its each token 
                - check this token in all the 1400 documents tokens 
                - If matches,write the doc id into the array.
                - Thus array contains the document ids multiple times
                - Construct the treemap having docid and its count .i.e frequencey of token in the documents
                - Write the token along with its docid and Tf on to the disk
                  (The written format is Token {Docid1:Tf1,Docid2:Tf2,...}
                Do the above steps for each token present in the Treeset.
            NOTE:As treeset contains the strings in the ascending order,all tokens will be in the order.
            This is the creation of inverted index.  
            */ 
            Iterator<String> iterator = treeset.iterator();
            PrintStream Diskfile = new PrintStream(new FileOutputStream("C:/Users/Dinesh/Desktop/IR_ASG1/InvertedIndex.txt"));

            while (iterator.hasNext()) {

                TreeMap<Integer, Integer> countMap = new TreeMap<>();
                ArrayList<Integer> arrays = new ArrayList<>();
                String checkintoken = iterator.next();

                for (int zz = 1; zz <= 1400; zz++) {
                    String tokenfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Token/" + zz + ".txt";
                    BufferedReader tokenfileBufferedReader = new BufferedReader(new FileReader(tokenfile));
                    String Tokenfiletext;
                    while ((Tokenfiletext = tokenfileBufferedReader.readLine()) != null) {
                        if ((Tokenfiletext.equals(checkintoken))) {
                            arrays.add(zz);
                        }
                    }
                } // for 1400

                for (Integer string : arrays) {
                    if (!countMap.containsKey(string)) {
                        countMap.put(string, 1);
                    } else {
                        Integer count = countMap.get(string);
                        count = count + 1;
                        countMap.put(string, count);
                    }
                }

                String printstr = " ";
                Set<Integer> keys = countMap.keySet();
                for (Integer key : keys) {
                    int counter = countMap.get(key);
                    String docid1 = Integer.toString(key);
                    String counter1 = Integer.toString(counter);
                    docid1 = docid1 + ":" + counter1;
                    if (" ".equals(printstr)) {
                        printstr = docid1;
                    } else {
                        printstr = printstr + " ," + docid1;
                    }
                }

                Diskfile.println(checkintoken + "  " + "{" + printstr + "}");

            }

        } catch (IOException ex) {
            System.out.println(ex);
        }

    }

}
