/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package IRPhase2;
import java.io.*;
import java.util.*;


/**
 *
 * @author Dinesh
 */
public class Vectorbuild {

//Find the no of documents those contain the token
    public static int FindN(String S)
    {
          int count = 0;  
         for(int i=0; i < S.length();i++)
         {
             if( S.charAt(i)== ':')
             {
                 count = count +1;
             } 
         }
       return count;
    }

   //Find the TF*IDF weight for a token wr.t document 
    public static double FindW(int x,int y,int N)
    {
         double weight; 
         double tf = 1+Math.log10(y);
         double idf = Math.log(1400/N);  
         weight = tf*idf;
         return weight;
    }
    

     public TreeMap Vectorbuild()
    {

        String Queryfile = "C:/Users/Dinesh/Desktop/IR_ASG1/QueryTokens.txt";
        String Query_Indexfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Queryindex.txt";
        String Query_VSM = "C:/Users/Dinesh/Desktop/IR_ASG1/VSM.txt";
        String Docs_Order = "C:/Users/Dinesh/Desktop/IR_ASG1/Ranking.txt";
        String scorefile = "C:/Users/Dinesh/Desktop/IR_ASG1/scorefile.txt";
                
         int N ;
         double idf; 
         String Ind;

         TreeSet<String> treeset = new TreeSet();
         TreeSet<Integer> treemap2 = new TreeSet();
         HashMap<Integer,Double> hashmap1 = new HashMap<>();
         HashMap<Integer,Double> hashmap = new HashMap<>();
         TreeMap<Double,Integer> treemap3 = new TreeMap(Collections.reverseOrder());
         ArrayList<String> Arrays2 = new ArrayList<>();
         
         try{
            
            PrintStream outfile3 = new PrintStream(new FileOutputStream(Query_VSM));  
            PrintStream scores = new PrintStream(new FileOutputStream(scorefile));
            PrintStream docsrank = new PrintStream(new FileOutputStream(Docs_Order));
            BufferedReader Ifile = new BufferedReader(new FileReader(Query_Indexfile));
            BufferedReader Qfile = new BufferedReader(new FileReader(Queryfile));
            String Iline;
            String Line;
        //  Add all the Query tokens to treeset     
            while((Line = Qfile.readLine())!=null)
            {
               treeset.add(Line);
            }
           
       //Read the query index file by matching with the treeset tokens
       // if the tree set token is found in the query index file, then add the token postings to the array
            
            while((Iline = Ifile.readLine())!=null)
            {
                       
               StringTokenizer Tokenized_String = new StringTokenizer(Iline, " || { || ,|| }");
               ArrayList<String> Arrays = new ArrayList<>();
                
               while(Tokenized_String.hasMoreTokens())
               {                           
                  String Current_Token = Tokenized_String.nextToken();
                 
                   if(treeset.contains(Current_Token))
                   {
                     String Mkey= Current_Token;
                     N = FindN(Iline); //No of documents contains this token
                     outfile3.print(Mkey+" {");
      
                     while(Tokenized_String.hasMoreTokens())
                      {
                          Current_Token = Tokenized_String.nextToken();
                          Arrays.add(Current_Token);
                      } 

                       for (String keys : Arrays)
                       {
                                           
                          int i =1;
                          int x= 0;
                          int y = 0;
                          for(String arys : keys.split(":"))
                          {
                              if(i==1){ x = Integer.valueOf(arys);}
                              else{ y=Integer.valueOf(arys);}
                              i = i+1;
                          }
                                            
                          treemap2.add(x);
                          double Weight =FindW(x,y,N);
                          outfile3.print(x+":"+Weight+",");
                          
                  //hashmap1 contains the document and its TF*IDFweight        
                          if (!hashmap1.containsKey(x))
                            { hashmap1.put(x,Weight); }
                          else
                             { double sum = hashmap1.get(x);
                               sum = sum + Weight;
                               hashmap1.put(x,sum);
                             }
 
                     }
                          outfile3.print("}");
                          outfile3.println(" ");
                   }
               }
            }
                 for(int xx : hashmap1.keySet())
                  {
                      hashmap.put(xx,hashmap1.get(xx));
                  } 
                
               double val;
               double m = 0.001;
               double n =1.0;
       //Do the page ranking here        
               for(int xx : hashmap1.keySet())
               {
                   val = hashmap1.get(xx);
                   m =0.001;
                   for(int key1 : hashmap.keySet())
                   {
                       if(val == hashmap.get(key1))
                        {
                           m = m*n;
                           n = n+1;
                           val = val+m;
                          hashmap.put(key1,val);
                         }
                    }    
               }
               
                  for(int xx : hashmap.keySet())
                  { 
                      scores.println(xx+" "+hashmap.get(xx));
                      treemap3.put(hashmap.get(xx), xx);  
                  } 
               
               
                for(double xx: treemap3.keySet())
                  {
                      docsrank.println(treemap3.get(xx));
                  } 

         } // try
         catch(IOException ex){System.out.println(ex);}
         return treemap3;
             }
    
}
