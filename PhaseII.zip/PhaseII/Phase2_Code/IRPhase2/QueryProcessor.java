/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package IRPhase2;               

import IRPhase1.*;
import java.io.*;
import java.util.*;        
/**
 *
 * @author Dinesh
 */
public class QueryProcessor 
{   
    
     /*QueryProcessor is used to created the inverted index for the user given query tokens
       -Query tokens are added to the treeset
       -Loop the treeset and check its token in the Phase1 created-inverted index.
       -if it matches,then write the index on to the QueryIndex file.
       - repeat the above steps for all tokens in the treeset. 
    */ 
    public String QueryProcess( )
    {
        String indexfile = "C:/Users/Dinesh/Desktop/IR_ASG1/InvertedIndex.txt";
        String Queryfile = "C:/Users/Dinesh/Desktop/IR_ASG1/QueryTokens.txt";
        String Query_Indexfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Queryindex.txt";
        
        TreeSet<String> treeset = new TreeSet();
  
        try{
           BufferedReader Qfile = new BufferedReader(new FileReader(Queryfile));
           String Line;
           while((Line = Qfile.readLine())!=null)
           {
               treeset.add(Line);
           }
           
           PrintStream outfile3 = new PrintStream(new FileOutputStream(Query_Indexfile)); 
           BufferedReader Ifile = new BufferedReader(new FileReader(indexfile));
           String Iline;
                  while((Iline = Ifile.readLine())!=null)
                   {
                       StringTokenizer Tokenized_String = new StringTokenizer(Iline, " ");
                       while(Tokenized_String.hasMoreTokens())
                       {
                            String Current_Token = Tokenized_String.nextToken();
                            if(treeset.contains(Current_Token))
                               {
                                   outfile3.println(Iline);
                                   
                               }
                       }
                   }
                   
      }
      catch(IOException ex){ System.out.println(ex);}
        return "YES";
 
       } // main
    } // class