/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package IRPhase2;

import java.io.*;
import java.util.*;

/**
 *
 * @author Dinesh
 */
public class GetDocTitle {

    /**
     * @param args the command line arguments
     */
    
    
    public String GetDocTitle(String Queryfile) 
    {
        //Queryfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Docs/1.txt";
      String Result = " ";
      
       try{
             BufferedReader Qfile = new BufferedReader(new FileReader(Queryfile));
             String docline;
             
             int TFound =0;
             int AFound =0;
             while((docline=Qfile.readLine())!=null)
             {
                if(AFound == 0)
                {   
                     if (docline.contains(".T"))
                     { 
                      
                     }
                     else
                     {
                        if (docline.contains(".A"))
                         {
                                 AFound = 1;  
                         }
                        else
                         {
                           Result = Result+docline;
                         }
                     }
                }
             }
           
              System.out.println("Title is"+Result);
           } // try
       catch(IOException ex){System.out.println(ex);}
       
       return Result;
    }
    
}
