/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IRPhase2;

import IRPhase1.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Dinesh
 */
public class Cranfilesearch extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
             long start = System.currentTimeMillis();
  // The below code is to display the Cranfile search Engine web page.            
            out.println("<html>");
            out.println("<head> <title> Cran File Search Engine </title> </head>");
            out.println("<body>");
            out.println("<div align = 'Center'>");
            out.println("<h1>  <font color=\"#0000FF\" face=\"Gungsuh\"> <b> Cran File Search Engine</b> </font> </h1>");
            out.println("<form>");
            out.println("Enter Your Query");
            out.println("<input type=\"text\" name=\"query\" size=100> ");
            out.println("<br>");
            out.println("<br>");
            out.println("<input type=\"submit\" value=\"Submit Query\">");
            out.println("<input type=\"reset\" value=\"Reset Form\">");
            out.println("</form> ");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
            String Query = request.getParameter("query");
            
 /*The object called 'Tokenizer' splits the user given query into tokens.
   The 'Tokenizer' object has two parameters.First parameter is query and Second parameter is an Tokenization indicator.
     It will be 'F' if document text is being parsed into tokens
     Otherwise 'Q' if user Query is being parsed into tokens
    Inaddition to this, the stop-words also will be removed from the tokenized text*/
            
            Tokenizer T = new Tokenizer();
            T.Tokenizer(Query, 'Q');
  /*QueryProcessor object is used to created the inverted index for the user given query tokens */         
            QueryProcessor Q = new QueryProcessor();
            Q.QueryProcess(); 
 /*GetDocTitle object is used to get the abstract title sothat same can be displayed on the web 
            page after searching the query*/           
            GetDocTitle G = new GetDocTitle();
            String doctitle = " ";
            int count = 0;
            String Vind = " ";
            TreeMap<Double,Integer> Treemap = new TreeMap(Collections.reverseOrder());
/*Vectorbuild object is used to evaluate the TF*IDF weights for the given query tokens and sort the documents based 
  on their cosine scores */  
            Vectorbuild V = new Vectorbuild();
            Treemap = V.Vectorbuild();

            String Ranksfile = "C:/Users/Dinesh/Desktop/IR_ASG1/Ranking.txt";
            
            for(Double key: Treemap.keySet())
            {
                if(count < 20) 
                {
                 count = count + 1;
                 int docid = Treemap.get(key);
                 String Rankdoc = "C:/Users/Dinesh/Desktop/IR_ASG1/Docs/" + docid + ".txt";
                 String Doctitle = G.GetDocTitle(Rankdoc);
                 double number = key;
                  number = Math.round(number * 100);
                  number = number/100; 
                 out.println("(DocId="+docid +", Score="+number + "  )");
                 out.println("<a href=\"http://C://Users//Dinesh//Desktop//IR_ASG1//Docs//" + docid + ".txt\">" + Doctitle + "</a>");
                 out.println("<br>");
                }
            }
            
             NumberFormat formatter = new DecimalFormat("#0.00000");
            long end = System.currentTimeMillis();
             out.println("<h4>  <font color=\"red\" face=\"Gungsuh\"> <b>Execution time is"+formatter.format((end - start) / 1000d)+"seconds </b> </font> </h4>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
