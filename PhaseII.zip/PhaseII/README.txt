Please follow the below steps to run the mentioned code
Requirements : JDK (Netbeans or Eclipse)
Phase-2
-------
Copy all the phase2 java program files into src file of projects
For the Phase2,main program is the Cranfilesearch.java.
Run this program.
It will take query as input and display the documents on the web page
All the files related to data set are located in Phase2_files doc.
